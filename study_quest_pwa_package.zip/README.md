# Study Quest PWA

## Files
- `index.html` — your Study Quest website, updated to load the PWA manifest and service worker
- `manifest.webmanifest` — app name, icon, theme, and install settings
- `sw.js` — caches the app shell for offline use
- `icons/icon-192.png` and `icons/icon-512.png` — app icons

## Free hosting with GitHub Pages
1. Sign in to GitHub and create a new public repository, for example `study-quest`.
2. Upload **all files and folders** from this package. Keep the `icons` folder and its two PNG files.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
5. Wait for GitHub Pages to publish your site. The address will look like `https://YOUR-USERNAME.github.io/study-quest/`.
6. Open that HTTPS address in Chrome on Android. Use the browser menu and choose **Install app** or **Add to Home screen**.

## Offline support
Open the hosted website once while online, wait a few seconds for it to cache, then try it offline. The app shell should load without a connection. Data remains in this browser/device because the current site uses localStorage; it does not sync between devices.

## Important notes
- Service workers require HTTPS (localhost is also allowed for testing); opening `index.html` directly as a `file://` file will not enable PWA installation/offline caching.
- If you update the website and changes do not appear, the service worker may still have the previous cache. The cache version is `study-quest-pwa-v1` in `sw.js`; change it to `study-quest-pwa-v2` after substantial updates, then redeploy.
- The daily reward is an in-app notification when you log enough study time. Browser/system notifications are not enabled by this starter version.
- GitHub Pages is free for public repositories. Hosting providers can change their plans and limits over time.

## Layout update
The current `index.html` includes a cleaner, responsive layout with more consistent spacing, a sticky compact navigation bar, and single-column cards on phone screens.
